# Three-condition telemetry (version 2.0.0 of this record)

Nine three-hour runs on a Raspberry Pi 5 running a duty-cycled MobileNetV2
classifier with ONNX Runtime (60 s active / 15 s sleep, camera-bound at
15 frame/s), 27-28 September 2026, in a randomised complete block design:

| Condition | Execution | Stack |
|---|---|---|
| A native  | host process | Python 3.13.5, glibc 2.41, ONNX Runtime 1.29.0 |
| B matched | Docker, debian:trixie-slim | same versions as the host; compiled extension modules byte-identical |
| C legacy  | Docker, python:3.9-slim-bullseye | Python 3.9.23, glibc 2.31, ONNX Runtime 1.19.2 |

Blocks (within-block order randomised, seed 20260927):
1 = legacy_1, matched_1, native_1; 2 = legacy_2, native_2, matched_2;
3 = matched_3, legacy_3, native_3.

## Files

- `runs/<label>/basil_data.csv.gz` - per-frame log: Timestamp (local time,
  UTC+8, no date), Latency_ms (InferenceSession.run only), FPS, CPU_%
  (system-wide), RAM_%, Temp_C, Throttled, Predicted_Class, Confidence,
  Bus_V_mV, Bus_I_mA, Bus_P_mW, Bat_V_mV, Bat_I_mA, Bat_Pct.
- `runs/<label>/power_log.csv` - 1 Hz log through active AND sleep phases:
  Timestamp, Phase, Bus_V_mV, Bus_I_mA, Bus_P_mW (Type-C input of the UPS HAT
  (E), i.e. node input power), Bat_V_mV, Bat_I_mA (positive = into the pack),
  Bat_Pct, Temp_C, CPU_%, Throttled, CPU_MHz, Cap_MHz, UV, Fan_RPM, Fan_PWM.
- `runs/<label>/cycle_events.csv` - duty-cycle transitions.
- `runs/<label>/RUN_INFO.txt` - run summary. The "Replicate" field holds the
  run's position in the schedule (1-9), not the replicate within the
  condition; the directory label identifies the replicate.
- `runs/<label>/provenance.json` - kernel, governor, cgroup cpu.max, CPU
  affinity, library versions, model SHA-256.
- `runs/<label>.camera.txt` - camera controls saved before each pinned run
  (from legacy_2 onward).
- `fp_host.json`, `fp_matched.json`, `fp_legacy.json` - environment
  fingerprints (taken 2026-09-27 02:03, before the first run).
- `run_plan.json`, `orchestrator.log` - schedule and orchestration log.
- `runner/` - harness, orchestrator, image definitions, fingerprinting script,
  and PROTOCOL.md (the procedure as executed, including the changes made
  during the campaign).

## Notes

- The first 600 s of each run are warm-up; 136 complete cycles per run remain.
- legacy_1 and matched_1 ran before the camera's dynamic frame rate was
  disabled (both held 15.0 frame/s). The original native_1 was discarded; the
  replacement ran on 27 September 20:19-23:19, after block 2. The harness was
  updated and the images rebuilt before legacy_2.
- Analysis code that regenerates every number in the accompanying paper:
  https://github.com/xiaolin200206/edge-container-deployment-measurement
  (directory three_condition, release v2.0-tsusc).

The greenhouse imagery and the first campaign's telemetry are not repeated in
this version; they remain in version 1.0.0 of this record:
https://doi.org/10.5281/zenodo.22857312
